import React,{useEffect,useRef,useState} from 'react';
import {Mic,Square,RotateCcw,Check,Info,FilePlus2,Settings,ClipboardList,ShieldCheck,Volume2} from 'lucide-react';

const EMPTY={entityName:'',entityType:'',tsp:'',services:'',bankName:'',branchName:'',assignedBy:'',date:''};
const LABELS={entityName:'Entity Name',entityType:'Entity Type',tsp:'TSP',services:'Services',bankName:'Bank Name',branchName:'Branch Name',assignedBy:'Task Assigned By',date:'Date'};
const OPTIONS={entityType:['Private Limited','Public Limited','Partnership','LLP','Proprietorship'],bankName:['HDFC Bank','ICICI Bank','State Bank of India','Axis Bank'],assignedBy:['Santhosh','Raj','Linto','Maheshwaran']};
const BRANCHES={'HDFC Bank':['Chennai','Bengaluru','Mumbai'],'ICICI Bank':['Chennai','Hyderabad','Delhi'],'State Bank of India':['Chennai','Coimbatore','Mumbai'],'Axis Bank':['Chennai','Pune','Delhi']};
const clean=v=>String(v||'').trim();
function optionMatch(value,options){if(!value)return '';return options.find(x=>x.toLowerCase()===clean(value).toLowerCase())||options.find(x=>x.toLowerCase().includes(clean(value).toLowerCase()))||'';}
function normalize(raw,existing){const result={};for(const key of Object.keys(EMPTY)){let value=clean(raw[key]);if(!value)continue;if(OPTIONS[key])value=optionMatch(value,OPTIONS[key]);if(key==='branchName'){const bank=raw.bankName?optionMatch(raw.bankName,OPTIONS.bankName):existing.bankName;value=optionMatch(value,BRANCHES[bank]||[]);}if(key==='date'&&!/^\d{4}-\d{2}-\d{2}$/.test(value))value='';if(value)result[key]=value;}return result;}
const Speech=typeof window!=='undefined'&&(window.SpeechRecognition||window.webkitSpeechRecognition);
function Field({label,required,children}){return <div><label className="field-label">{label} {required&&<span className="required">*</span>}</label>{children}</div>}
function Section({num,title,children}){return <section className="panel"><h2 className="font-bold text-[16px] mb-5 flex items-center gap-3"><span className="bg-[#1d3c6c] text-white rounded-md px-2 py-1 text-xs">{num}</span>{title}</h2><div className="grid md:grid-cols-2 gap-x-14 gap-y-4">{children}</div></section>}
export default function App(){
 const [form,setForm]=useState(EMPTY),[mode,setMode]=useState('browser'),[recording,setRecording]=useState(false),[transcript,setTranscript]=useState(''),[draft,setDraft]=useState(null),[notice,setNotice]=useState(''),[busy,setBusy]=useState(false),[history,setHistory]=useState([]);
 const speechRef=useRef(null),recorderRef=useRef(null),chunksRef=useRef([]),streamRef=useRef(null),audioRef=useRef(null),transcriptRef=useRef('');
 const update=(key,value)=>setForm(p=>({...p,[key]:value,...(key==='bankName'?{branchName:''}:{})}));
 const stopTracks=()=>{streamRef.current?.getTracks().forEach(t=>t.stop());streamRef.current=null};
 useEffect(()=>()=>{try{speechRef.current?.abort()}catch{};try{recorderRef.current?.stop()}catch{};stopTracks()},[]);
 const start=async()=>{setNotice('');setDraft(null);setTranscript('');transcriptRef.current='';
  if(mode==='browser'){
   if(!Speech){setNotice('Browser speech recognition is unavailable. Try Chrome or Edge, or use PHP + Gemini audio mode.');return;}
   const rec=new Speech();speechRef.current=rec;rec.lang='en-IN';rec.continuous=true;rec.interimResults=true;
   rec.onresult=e=>{let words='';for(let i=0;i<e.results.length;i++)words+=e.results[i][0].transcript+' ';transcriptRef.current=words.trim();setTranscript(words.trim());};
   rec.onerror=e=>{setNotice(`Speech recognition: ${e.error}. Please try again.`);setRecording(false)};
   rec.onend=()=>setRecording(false);
   try{rec.start();setRecording(true)}catch(e){setNotice(e.message)}
  }else{
   try{const stream=await navigator.mediaDevices.getUserMedia({audio:true});streamRef.current=stream;chunksRef.current=[];
    const preferred=['audio/webm;codecs=opus','audio/webm','audio/mp4'].find(x=>MediaRecorder.isTypeSupported(x));
    const rec=new MediaRecorder(stream,preferred?{mimeType:preferred}:undefined);recorderRef.current=rec;
    rec.ondataavailable=e=>{if(e.data.size)chunksRef.current.push(e.data)};
    rec.onstop=()=>{audioRef.current=new Blob(chunksRef.current,{type:rec.mimeType||'audio/webm'});stopTracks();if(audioRef.current.size<1500)setNotice('Recording is very short. Try speaking again.');};
    rec.start();setRecording(true);
   }catch(e){setNotice(`Microphone access failed: ${e.message}`)}
  }
 };
 const stop=()=>{if(mode==='browser'){try{speechRef.current?.stop()}catch{};setTranscript(transcriptRef.current)}else{try{recorderRef.current?.stop()}catch{}}setRecording(false)};
 const extract=async()=>{
  setBusy(true);setNotice('');setDraft(null);
  try{
   let response;
   if(mode==='browser'){
    const text=transcriptRef.current.trim();if(!text){setNotice('No speech detected. Please record your details first.');return;}
    response=await fetch('/api/extract.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({transcript:text,allowedOptions:{...OPTIONS,branches:BRANCHES},existing:form})});
   }else{
    if(!audioRef.current||audioRef.current.size<1500){setNotice('No usable audio recording found. Record again.');return;}
    const body=new FormData();body.append('audio',audioRef.current,'recording.webm');body.append('allowedOptions',JSON.stringify({...OPTIONS,branches:BRANCHES}));body.append('existing',JSON.stringify(form));
    response=await fetch('/api/audio.php',{method:'POST',body});
   }
   const raw = await response.text();

   if (!raw.trim()) {
     throw new Error(
       `Server returned an empty response (HTTP ${response.status}). Check PHP logs.`
     );
   }
   
   let data;
   
   try {
     data = JSON.parse(raw);
   } catch {
     console.error("Invalid API response:", raw);
     throw new Error(
       `Invalid backend response (HTTP ${response.status}).`
     );
   }
   
   if (!response.ok) {
     throw new Error(
       data.error || `Voice processing failed (HTTP ${response.status}).`
     );
   }
   
   if(!response.ok)throw new Error(data.error||'Processing failed');
   if(data.transcript){setTranscript(data.transcript);transcriptRef.current=data.transcript}
   const extracted=normalize(data.fields||{},form);if(!Object.keys(extracted).length){setNotice('No recognizable form details were found. Try again with more information.');return;}
   setDraft(extracted);setNotice(`Found ${Object.keys(extracted).length} field(s). Review before applying.`);
  }catch(e){setNotice(e.message)}finally{setBusy(false)}
 };
 const apply=()=>{if(!draft)return;setForm(prev=>{const next={...prev,...draft};if(draft.bankName&&draft.bankName!==prev.bankName&&!draft.branchName)next.branchName='';return next});setHistory(h=>[...h,{time:new Date().toLocaleTimeString(),count:Object.keys(draft).length}]);setDraft(null);setNotice('Fields applied. You can record again to fill missing information.');audioRef.current=null};
 const reset=()=>{setForm(EMPTY);setDraft(null);setTranscript('');transcriptRef.current='';setNotice('Form cleared.');setHistory([])};
 const submit=e=>{e.preventDefault();const required=['entityName','entityType','services','bankName','assignedBy','date'];const missing=required.filter(k=>!form[k]);if(missing.length){setNotice('Complete required fields: '+missing.map(k=>LABELS[k]).join(', '));return;}setNotice('Form validated successfully. Demo only: connect this action to your PHP save endpoint.');};
 const input=(key,placeholder)=> <input className="field" placeholder={placeholder} value={form[key]} onChange={e=>update(key,e.target.value)}/>;
 const select=(key,placeholder,values,disabled=false)=> <select className="field" value={form[key]} disabled={disabled} onChange={e=>update(key,e.target.value)}><option value="">{placeholder}</option>{values.map(x=><option key={x} value={x}>{x}</option>)}</select>;
 return <div className="min-h-screen md:flex"><aside className="md:w-[230px] bg-[#11264b] text-white px-5 py-6 shrink-0"><div className="font-extrabold text-lg mb-5">◇ Fintech Portal</div><p className="text-xs leading-5 text-slate-300 mb-10">Account Opening<br/>Management Platform</p><nav className="space-y-2 text-sm"><div className="rounded-lg bg-[#385783] p-3 flex gap-2 items-center"><FilePlus2 size={15}/> Add New Request</div><div className="p-3 flex gap-2 items-center text-slate-300"><ClipboardList size={15}/> Requests</div><div className="p-3 flex gap-2 items-center text-slate-300"><Settings size={15}/> Settings</div></nav></aside><main className="flex-1 min-w-0"><header className="bg-[#e6efff] px-6 md:px-10 py-5 flex justify-between items-center"><div><h1 className="font-bold text-xl">Add New Request</h1><p className="mini">Entity, bank and assignment details</p></div><span className="text-xs rounded-full border border-blue-100 bg-white/70 px-3 py-2 flex gap-1 items-center"><ShieldCheck size={14}/> External Access</span></header><form onSubmit={submit} className="max-w-[1040px] mx-auto px-4 md:px-8 py-8 space-y-4">
 <Section num="1" title="Entity Information"><Field label="Entity Name" required>{input('entityName','Enter entity name')}</Field><Field label="Entity Type" required>{select('entityType','Select entity type',OPTIONS.entityType)}</Field><Field label="TSP">{input('tsp','Enter TSP')}</Field><Field label="Services" required>{input('services','Enter services')}</Field></Section>
 <Section num="2" title="Bank Information"><Field label="Bank Name" required>{select('bankName','Select bank',OPTIONS.bankName)}</Field><Field label="Branch Name">{select('branchName',form.bankName?'Select branch':'Select a bank first',BRANCHES[form.bankName]||[],!form.bankName)}<p className="mini mt-2">Branch options load once a bank is selected.</p></Field></Section>
 <Section num="3" title="Assignment Information"><Field label="Task Assigned By" required>{select('assignedBy','Select assigned by',OPTIONS.assignedBy)}</Field><Field label="Date" required><input type="date" className="field" value={form.date} onChange={e=>update('date',e.target.value)}/></Field></Section>
 <section className="rounded-2xl border border-[#cddcf5] p-5 bg-[#f8faff]"><div className="flex flex-wrap justify-between gap-3 mb-3"><div><h2 className="font-bold flex gap-3 items-center"><span className="bg-[#1d3c6c] text-white rounded-md px-2 py-1 text-xs">4</span>Voice-Assisted Form Filling <span className="text-[10px] tracking-wider text-blue-700">OPTIONAL</span></h2><p className="mini mt-2">Record your request details and populate the fields above. Multiple recordings are supported.</p></div><div><label className="mini block mb-1">Recognition mode</label><select className="field !text-xs" value={mode} disabled={recording||busy} onChange={e=>{setMode(e.target.value);setDraft(null);setTranscript('');audioRef.current=null}}><option value="browser">Browser Speech + PHP Gemini extraction</option><option value="audio">Audio recording + PHP Gemini</option></select></div></div>
 <div className="border border-dashed border-blue-200 bg-white rounded-xl p-4 flex flex-wrap gap-4 items-center justify-between"><div className="flex items-center gap-3"><span className="rounded-full bg-blue-50 p-3"><Mic size={21}/></span><div><strong className="text-sm">{recording?'Listening / recording...':'Ready to record'}</strong><p className="mini">{mode==='browser'?'Speech is transcribed by your browser.':'Audio is recorded and processed by the PHP backend.'}</p></div></div><div className="flex flex-wrap gap-2">{!recording?<button type="button" className="action primary flex items-center gap-2" onClick={start}><Mic size={15}/> Start Recording</button>:<button type="button" className="action bg-red-600 text-white flex gap-2 items-center" onClick={stop}><Square size={14}/> Stop Recording</button>}<button type="button" disabled={recording||busy} onClick={extract} className="action secondary">{busy?'Processing...':'Process Recording'}</button></div></div>
 {transcript&&<div className="bg-white rounded-lg border border-blue-100 mt-3 p-3"><p className="font-semibold text-sm mb-1 flex items-center gap-2"><Volume2 size={14}/> Recognized speech</p><p className="text-sm text-slate-600">{transcript}</p></div>}
 {notice&&<div role="status" className="text-sm text-[#285389] bg-[#eaf2ff] rounded-lg px-3 py-2 mt-3 flex items-start gap-2"><Info size={16} className="mt-0.5 shrink-0"/>{notice}</div>}
 {draft&&<div className="mt-3 rounded-xl bg-white border border-blue-100 p-4"><h3 className="font-bold text-sm mb-3">Recognized information — review before applying</h3><div className="grid md:grid-cols-2 gap-2">{Object.entries(draft).map(([k,v])=><div key={k} className="rounded-md bg-[#f4f7fc] p-3"><div className="mini">{LABELS[k]}</div><div className="text-sm font-semibold">{v}</div>{form[k]&&form[k]!==v&&<div className="text-xs text-amber-700 mt-1">Will replace: {form[k]}</div>}</div>)}</div><div className="flex justify-end gap-2 mt-4"><button type="button" className="action secondary" onClick={()=>setDraft(null)}>Discard</button><button type="button" className="action primary flex gap-1 items-center" onClick={apply}><Check size={15}/> Apply to Form</button></div></div>}
 <div className="flex flex-wrap justify-between items-center mt-3 gap-2"><span className="mini">{Object.values(form).filter(Boolean).length}/8 fields filled · {history.length} recording(s) applied</span><span className="mini">Existing values are preserved unless a new recognized value explicitly replaces them.</span></div></section>
 <div className="flex justify-end gap-2 pt-3"><button type="button" onClick={reset} className="action secondary flex gap-2 items-center"><RotateCcw size={14}/> Cancel / Clear</button><button type="submit" className="action primary">Submit Request</button></div>
 </form></main></div>
}
